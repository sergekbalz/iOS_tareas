//
//  sevenmultiple.m
//  Tarea_2
//
//  Created by localadmin on 11/11/16.
//  Copyright © 2016 localadmin. All rights reserved.
//

#import "sevenmultiple.h"
#define MULT_KEY @"mult"
#define RESULT_KEY @"result"

@interface sevenmultiple ()
@property(nonatomic,strong) NSArray *resultsArray;

@end

@implementation sevenmultiple

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createDictionary];


}

-(void)createDictionary{
    NSDictionary *firstDictionary = @{MULT_KEY:@"7x1=", RESULT_KEY:@"7"};
    NSDictionary *secondDictionary = @{MULT_KEY:@"7x2=", RESULT_KEY:@"14"};
    NSDictionary *thirdDictionary = @{MULT_KEY:@"7x3=", RESULT_KEY:@"21"};
    NSDictionary *fourthDictionary = @{MULT_KEY:@"7x4=", RESULT_KEY:@"28"};
    NSDictionary *fifthDictionary = @{MULT_KEY:@"7x5=", RESULT_KEY:@"35"};
    NSDictionary *sixthDictionary = @{MULT_KEY:@"7x6=", RESULT_KEY:@"42"};
    NSDictionary *seventhDictionary = @{MULT_KEY:@"7x7=", RESULT_KEY:@"49"};
    NSDictionary *eightDictionary = @{MULT_KEY:@"7x8=", RESULT_KEY:@"56"};
    NSDictionary *ninthDictionary = @{MULT_KEY:@"7x9=", RESULT_KEY:@"63"};
    NSDictionary *tenthDictionary = @{MULT_KEY:@"7x10=", RESULT_KEY:@"70"};
    NSDictionary *eleventhDictionary = @{MULT_KEY:@"7x11=", RESULT_KEY:@"77"};
    
    
    self.resultsArray = [[NSArray alloc] initWithObjects:firstDictionary,secondDictionary,thirdDictionary,fourthDictionary,fifthDictionary,sixthDictionary,seventhDictionary,eightDictionary,ninthDictionary,tenthDictionary,eleventhDictionary, nil];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.resultsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
                             NSDictionary *currentTable = self.resultsArray[indexPath.row];
                             cell.textLabel.text=[currentTable valueForKey:MULT_KEY];
                             cell.detailTextLabel.text=[currentTable valueForKey:RESULT_KEY];
                             
                             return cell;
                            
                             
}

/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
