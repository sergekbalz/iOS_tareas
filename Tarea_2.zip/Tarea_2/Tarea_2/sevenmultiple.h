//
//  sevenmultiple.h
//  Tarea_2
//
//  Created by localadmin on 11/11/16.
//  Copyright © 2016 localadmin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sevenmultiple : UITableViewController

@end
