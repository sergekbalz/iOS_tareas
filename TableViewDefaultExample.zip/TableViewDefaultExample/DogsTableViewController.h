//
//  DogsTableViewController.h
//  TableViewDefaultExample
//
//  Created by Estudiantes on 10/29/16.
//  Copyright © 2016 gv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DogsTableViewController : UITableViewController

@end
